from train.hash_train import Trainer


if __name__ == "__main__":

    Trainer()


